﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GridViewStudentInformation
{
    class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public Student()
        {

        }
        public Student(int id, string name, string address)
        {
            ID = id;
            Name = name;
            Address = address;
        }

        public List<Student> GetStudentsList()
        {
            List<Student> students = new List<Student>(){
            new Student(1,"Ali", "4, Sector X, DHA, Lahore"),
            new Student(2,"Azhar", "54, Block-C, Model Town, Lahore"),
            new Student(3,"Babar", "10, Block-A, Johar Town, Lahore"),
            new Student(4,"Bazaib", "44, Block-C, Township, Lahore"),
            new Student(5,"Faizan", "255, Sector-A, Gulberg, Lahore"),
            new Student(6,"Fatima", "9, Sector DD, DHA, Lahore"),
            new Student(7,"Fauzia", "123, Block-X, Johar Town, Lahore"),
            new Student(8,"Gabrial", "4, BOR Society, Lahore"),
            new Student(9,"Gulzar", "6, Sector C, DHA, Lahore"),
            new Student(10,"Zulfikar", "420, Green Town, Lahore")
            };
            return students;
        }
    }
    public partial class GridViewStudents : System.Web.UI.Page
    {
        private List<Student> studentList = new Student().GetStudentsList();
        protected void Page_Load(object sender, EventArgs e)
        {
            StudentsGridView.DataSource = studentList; 
            StudentsGridView.DataBind();
            StudentsGridView.HeaderRow.TableSection = TableRowSection.TableHeader;
        }
    }
}